package com.x.hadoop.mr.bbs;

public class Info {

}
